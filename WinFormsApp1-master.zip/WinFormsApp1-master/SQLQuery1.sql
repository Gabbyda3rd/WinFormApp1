﻿CREATE TABLE clients(
	id INT NOT NULL PRIMARY KEY IDENTITY,
	fullname VARCHAR(100) NOT NULL,
	age VARCHAR(100) NOT NULL
);

INSERT INTO clients (fullname,age) 
VALUES
('Albert Malate' ,'23'),
('Gabriel Malate' ,'24');