﻿namespace WinFormsApp1
{
    partial class CreateEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbTitle = new Label();
            lbClientId = new Label();
            lbId = new Label();
            lbName = new Label();
            lbAge = new Label();
            tbName = new TextBox();
            tbAge = new TextBox();
            BtnSave = new Button();
            BtnCancel = new Button();
            SuspendLayout();
            // 
            // lbTitle
            // 
            lbTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lbTitle.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbTitle.Location = new Point(12, 9);
            lbTitle.Name = "lbTitle";
            lbTitle.Size = new Size(776, 37);
            lbTitle.TabIndex = 0;
            lbTitle.Text = "Create Client";
            lbTitle.TextAlign = ContentAlignment.TopCenter;
            // 
            // lbClientId
            // 
            lbClientId.AutoSize = true;
            lbClientId.Location = new Point(38, 102);
            lbClientId.Name = "lbClientId";
            lbClientId.Size = new Size(18, 15);
            lbClientId.TabIndex = 1;
            lbClientId.Text = "ID";
            // 
            // lbId
            // 
            lbId.AutoSize = true;
            lbId.Location = new Point(79, 102);
            lbId.Name = "lbId";
            lbId.Size = new Size(0, 15);
            lbId.TabIndex = 2;
            // 
            // lbName
            // 
            lbName.AutoSize = true;
            lbName.Location = new Point(38, 133);
            lbName.Name = "lbName";
            lbName.Size = new Size(61, 15);
            lbName.TabIndex = 3;
            lbName.Text = "Full Name";
            // 
            // lbAge
            // 
            lbAge.AutoSize = true;
            lbAge.Location = new Point(38, 160);
            lbAge.Name = "lbAge";
            lbAge.Size = new Size(28, 15);
            lbAge.TabIndex = 4;
            lbAge.Text = "Age";
            // 
            // tbName
            // 
            tbName.Location = new Point(105, 125);
            tbName.Name = "tbName";
            tbName.Size = new Size(246, 23);
            tbName.TabIndex = 5;
            // 
            // tbAge
            // 
            tbAge.Location = new Point(105, 157);
            tbAge.Name = "tbAge";
            tbAge.Size = new Size(246, 23);
            tbAge.TabIndex = 6;
            // 
            // BtnSave
            // 
            BtnSave.Location = new Point(105, 203);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(97, 46);
            BtnSave.TabIndex = 7;
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = true;
            BtnSave.Click += BtnSave_Click;
            // 
            // BtnCancel
            // 
            BtnCancel.Location = new Point(254, 203);
            BtnCancel.Name = "BtnCancel";
            BtnCancel.Size = new Size(97, 46);
            BtnCancel.TabIndex = 8;
            BtnCancel.Text = "Cancel";
            BtnCancel.UseVisualStyleBackColor = true;
            BtnCancel.Click += BtnCancel_Click;
            // 
            // CreateEditForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 298);
            Controls.Add(BtnCancel);
            Controls.Add(BtnSave);
            Controls.Add(tbAge);
            Controls.Add(tbName);
            Controls.Add(lbAge);
            Controls.Add(lbName);
            Controls.Add(lbId);
            Controls.Add(lbClientId);
            Controls.Add(lbTitle);
            Name = "CreateEditForm";
            Text = "CreateEditForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbTitle;
        private Label lbClientId;
        private Label lbId;
        private Label lbName;
        private Label lbAge;
        private TextBox tbName;
        private TextBox tbAge;
        private Button BtnSave;
        private Button BtnCancel;
    }
}