﻿using System;
using System.Windows.Forms;
using WinFormsApp1.Models;
using WinFormsApp1.Repositories;

namespace WinFormsApp1
{
    public partial class CreateEditForm : Form
    {
        private int clientId = 0; // Store the client ID for update operations

        public CreateEditForm()
        {
            InitializeComponent();
            DialogResult = DialogResult.Cancel; // Default to Cancel when closing the form
        }

        // Method to populate the form for editing an existing client
        public void EditClient(Client client, Label v)
        {
            this.Text = "Edit Client"; // Change the form title to indicate edit mode
            this.lbTitle = v; // This may be used for a custom title or label handling

            // Set the form controls with the client's existing values
            this.lbId.Text = client.id.ToString(); // Display client ID
            this.tbName.Text = client.fullname; // Display client name in TextBox
            this.tbAge.Text = client.age; // Display client age in TextBox

            this.clientId = client.id; // Store the client ID for later use
        }

        // Save the client, either creating or updating it based on the ID
        private void BtnSave_Click(object sender, EventArgs e)
        {
            Client client = new()
            {
                id = this.clientId,
                fullname = this.tbName.Text,
                age = this.tbAge.Text
            };

            var repo = new ClientRepository();

            if (client.id == 0) // If client ID is 0, it's a new client
            {
                repo.CreateClient(client);
            }
            else // If client ID is not 0, update the existing client
            {
                repo.UpdateClient(client);
            }

            this.DialogResult = DialogResult.OK; // Close the form and signal that changes are saved
        }

        // Cancel the action and close the form without saving changes
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; // Close form without making changes
        }

        internal void EditClient(Client client, object lbTitle)
        {
            throw new NotImplementedException();
        }

        internal void EditClient(Client client)
        {
            throw new NotImplementedException();
        }
    }
}
