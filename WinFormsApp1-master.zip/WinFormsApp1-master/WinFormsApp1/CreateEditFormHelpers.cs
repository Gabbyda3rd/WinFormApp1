﻿internal static class CreateEditFormHelpers
{

    private const string V = "Edit Client";
}