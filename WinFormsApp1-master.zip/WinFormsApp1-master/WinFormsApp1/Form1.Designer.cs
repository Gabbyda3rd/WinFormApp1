﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            BtnAddClient = new Button();
            BtnDelete = new Button();
            BtnEdit = new Button();
            clientTable = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)clientTable).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(723, 39);
            label1.TabIndex = 0;
            label1.Text = "List Of Client";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // BtnAddClient
            // 
            BtnAddClient.Location = new Point(12, 76);
            BtnAddClient.Name = "BtnAddClient";
            BtnAddClient.Size = new Size(118, 46);
            BtnAddClient.TabIndex = 1;
            BtnAddClient.Text = "Add Client ";
            BtnAddClient.UseVisualStyleBackColor = true;
            BtnAddClient.Click += BtnAdd_Click;
            // 
            // BtnDelete
            // 
            BtnDelete.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            BtnDelete.Location = new Point(617, 77);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(118, 46);
            BtnDelete.TabIndex = 2;
            BtnDelete.Text = "Delete";
            BtnDelete.UseVisualStyleBackColor = true;
            // 
            // BtnEdit
            // 
            BtnEdit.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            BtnEdit.Location = new Point(482, 79);
            BtnEdit.Name = "BtnEdit";
            BtnEdit.Size = new Size(118, 44);
            BtnEdit.TabIndex = 3;
            BtnEdit.Text = "Edit";
            BtnEdit.UseVisualStyleBackColor = true;
            BtnEdit.Click += BtnEdit_Click;
            // 
            // clientTable
            // 
            clientTable.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            clientTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            clientTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            clientTable.Location = new Point(12, 139);
            clientTable.MultiSelect = false;
            clientTable.Name = "clientTable";
            clientTable.RowHeadersVisible = false;
            clientTable.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            clientTable.Size = new Size(723, 298);
            clientTable.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(747, 450);
            Controls.Add(clientTable);
            Controls.Add(BtnEdit);
            Controls.Add(BtnDelete);
            Controls.Add(BtnAddClient);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Client Manager";
            ((System.ComponentModel.ISupportInitialize)clientTable).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Button BtnAddClient;
        private Button BtnDelete;
        private Button BtnEdit;
        private DataGridView clientTable;
    }
}
