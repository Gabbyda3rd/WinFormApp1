using System;
using System.Data;
using WinFormsApp1.Models;
using WinFormsApp1.Repositories;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ReadClients();
        }

        private void ReadClients()
        {
            DataTable dataTable = new();
            dataTable.Columns.Add("Id");
            dataTable.Columns.Add("Name");
            dataTable.Columns.Add("Age");

            var repo = new ClientRepository();
            var clients = repo.GetClients();

            foreach (var client in clients)
            {
                var row = dataTable.NewRow();
                row["Id"] = client.id;
                row["Name"] = client.fullname;
                row["Age"] = client.age;

                dataTable.Rows.Add(row);
            }

            clientTable.DataSource = dataTable;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            CreateEditForm form = new();
            if (form.ShowDialog() == DialogResult.OK)
            {
                // Refresh the client list after adding a new client
                ReadClients();
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (clientTable.SelectedRows.Count == 0) return;

            var selectedValue = clientTable.SelectedRows[0].Cells[0].Value?.ToString();
            if (string.IsNullOrEmpty(selectedValue)) return;

            if (!int.TryParse(selectedValue, out int clientId)) return;

            var repo = new ClientRepository();
            var client = repo.GetClient(clientId);
            if (client == null) return;

            CreateEditForm form = new();
            form.EditClient(client); // Pass the client to be edited
            if (form.ShowDialog() == DialogResult.OK)
            {
                // Refresh the client list after editing
                ReadClients();
            }
        }
    }
}
