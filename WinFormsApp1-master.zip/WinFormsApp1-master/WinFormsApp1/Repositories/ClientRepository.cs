﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using WinFormsApp1.Models;

namespace WinFormsApp1.Repositories
{
    public class ClientRepository
    {
        private readonly string connectionString = "Data Source=.;Initial Catalog=winformdb;Integrated Security=True;Trust Server Certificate=True";

        public List<Client> GetClients()
        {
            var clients = new List<Client>();

            try
            {
                using SqlConnection connection = new(connectionString);
                connection.Open();

                string sql = "SELECT * FROM clients";
                using SqlCommand cmd = new(sql, connection);
                using SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    clients.Add(new Client
                    {
                        id = reader.GetInt32(0),
                        fullname = reader.GetString(1),
                        age = reader.GetString(2)
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }

            return clients;
        }

        public Client? GetClient(int id)
        {
            try
            {
                using SqlConnection connection = new(connectionString);
                connection.Open();

                string sql = "SELECT * FROM clients WHERE id=@id";
                using SqlCommand command = new(sql, connection);
                command.Parameters.AddWithValue("@id", id);

                using SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    return new Client
                    {
                        id = reader.GetInt32(0),
                        fullname = reader.GetString(1),
                        age = reader.GetString(2)
                    };
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }

            return null;
        }

        public void CreateClient(Client client)
        {
            try
            {
                using SqlConnection connection = new(connectionString);
                connection.Open();

                string sql = "INSERT INTO clients (fullname, age) VALUES (@fullname, @age)";
                using SqlCommand cmd = new(sql, connection);
                cmd.Parameters.AddWithValue("@fullname", client.fullname);
                cmd.Parameters.AddWithValue("@age", client.age);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
        }

        public void UpdateClient(Client client)
        {
            try
            {
                using SqlConnection connection = new(connectionString);
                connection.Open();

                string sql = "UPDATE clients SET fullname=@fullname, age=@age WHERE id=@id";
                using SqlCommand cmd = new(sql, connection);
                cmd.Parameters.AddWithValue("@id", client.id);
                cmd.Parameters.AddWithValue("@fullname", client.fullname);
                cmd.Parameters.AddWithValue("@age", client.age);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
        }

        public void DeleteClient(int id)
        {
            try
            {
                using SqlConnection connection = new(connectionString);
                connection.Open();

                string sql = "DELETE FROM clients WHERE id=@id";
                using SqlCommand cmd = new(sql, connection);
                cmd.Parameters.AddWithValue("@id", id);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
        }
    }
}
