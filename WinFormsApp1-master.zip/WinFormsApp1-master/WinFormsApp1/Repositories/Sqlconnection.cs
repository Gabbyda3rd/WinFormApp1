﻿namespace WinFormsApp1.Repositories
{
    internal class Sqlconnection
    {
        private string connectionString;

        public Sqlconnection(string connectionString)
        {
            this.connectionString = connectionString;
        }
    }
}